import numpy as np
import matplotlib.pyplot as plt




h1 = 0.25
h2 = 0.125
t = np.arange(0, 4 + h1, h1) #values on x axis


#--------------------------------------------------------------------------------------------------------
#Euler Method (h=0.25)

f = lambda t, s: s*((t**2)-1.1) #y'(t)=yt^2-1.1y
 
s0 = 1 
s = np.zeros(len(t))
s[0] = s0 #initial condition

for i in range(0, len(t) - 1): 
    s[i + 1] = s[i] + h1*f(t[i], s[i]) #iteration values

#Euler Method (h=0.125)
    
f = lambda t, sn: sn*((t**2)-1.1)
 
sn0 = 1 
sn = np.zeros(len(t))
sn[0] = sn0

for i in range(0, len(t) - 1):
    sn[i + 1] = sn[i] + h2*f(t[i], sn[i])  
    
#--------------------------------------------------------------------------------------------------------

#4th Order Explicit RK method

f = lambda t, y: y*((t**2)-1.1) 
y = np.zeros(len(t))
y[0] = 1
  
for i in range(0, len(t)-1):
    k1 = h1 * f(t[i], y[i])
    k2 = h1 * f(t[i] + 0.5 * h1, y[i] + 0.5 * k1)
    k3 = h1 * f(t[i] + 0.5 * h1, y[i] + 0.5 * k2)
    k4 = h1 * f(t[i] + h1, y[i] + k3)    
    y[i+1] = y[0] + (1/6)*(k1 + 2 * k2 + 2 * k3 + k4)
    
#--------------------------------------------------------------------------------------------------------     
  
# 2 stage Implicit RK Method

f = lambda t, q: q*((t**2)-1.1) 
q = np.zeros(len(t))
q[0] = 1
k1=0
k2=0
for i in range(0, len(t)-1):
    k1 = f(t[i]+(0.5+((3)**0.5)/6)*h1,q[i]+1/4*k1+(1/4+((3)**0.5)/6)*h1*k2)
    k2 = f(t[i]+(0.5-((3)**0.5)/6)*h1,q[i]+1/4*k2+(1/4-((3)**0.5)/6)*h1*k1)
    q[i+1] = q[0]+(h1/2)*(k1+k2) 
    
#---------------------------------------------------------------------------------------------------------  
    
    
plt.figure(figsize = (12, 8))
plt.plot(t, np.exp((((t**3)/3)-1.1*t)), 'g', label='Exact')
plt.plot(t, s, label='Euler(0.25)')
plt.plot(t, sn, label='Euler(0.125)', color='magenta')
plt.plot(t, y, label='RK4')
plt.plot(t, q, label='ImpRK2', color='black')
plt.xlabel('t')
plt.ylabel('y')
plt.grid()
plt.legend(loc='upper left')
plt.show()
